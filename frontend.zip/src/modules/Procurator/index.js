export { default as TeacherList } from './views/TeacherList';
export { default as StudentList } from './views/StudentList';
export { default as UploadDocuments } from './views/UploadDocuments';
