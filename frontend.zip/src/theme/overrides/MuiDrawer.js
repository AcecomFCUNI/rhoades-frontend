import { custom } from '../palette';

const customStyle = {
  paper: {
    backgroundColor: custom.primary.main,
  },
};

export default customStyle
