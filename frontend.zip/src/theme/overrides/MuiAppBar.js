import { custom } from '../palette';

const palette = {
  colorPrimary: {
    backgroundColor: custom.white,
  },
};

export default palette
