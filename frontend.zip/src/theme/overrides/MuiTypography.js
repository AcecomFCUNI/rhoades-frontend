const customStyle = {
  gutterBottom: {
    marginBottom: 8
  }
};

export default customStyle