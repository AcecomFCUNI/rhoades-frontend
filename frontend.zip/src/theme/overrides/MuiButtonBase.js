import palette from '../palette';

const customStyle = {
  root: {
    color: palette.white,
  },
};

export default customStyle
