export { default as ErrorLayout } from './Error';
export { default as PublicLayout } from './Public';
export { default as StudentLayout } from './Student';
export { default as TeacherLayout } from './Teacher';
export { default as ProcuratorLayout } from './Procurator';
export { default as AdminLayout } from './Admin';
